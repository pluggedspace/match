from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from matches.models import Prediction, Match, Gameweek,Fixture
from matches.serializers import PredictionSerializer
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework import status
from matches.logic.train_and_predict import train_and_predict

from rest_framework.views import APIView
from rest_framework import status

from .serializers import GameweekSerializer
from django.utils.timezone import now

class PredictionViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Prediction.objects.select_related('match')
    serializer_class = PredictionSerializer

    @action(detail=False, methods=['get'], url_path='upcoming')
    def upcoming(self, request):
        upcoming_matches = Match.objects.filter(result__isnull=True)
        predictions = Prediction.objects.filter(match__in=upcoming_matches).select_related('match')
        serializer = self.get_serializer(predictions, many=True)
        return Response(serializer.data)
        
        

@api_view(['POST'])
@permission_classes([IsAdminUser])
def retrain_predictions(request):
    result = train_and_predict()

    if result['status'] == "fail":
        return Response(result, status=status.HTTP_400_BAD_REQUEST)

    return Response(result, status=status.HTTP_200_OK)
    


class CurrentGameweekAPIView(APIView):
    """
    Returns the current gameweek and its fixtures with predictions
    """
    def get(self, request, format=None):
        today = now()
        gw = Gameweek.objects.filter(start_date__lte=today, end_date__gte=today).first()
        if not gw:
            return Response({"detail": "No active gameweek found."}, status=status.HTTP_404_NOT_FOUND)

        # Fetch fixtures within date range
        fixtures = Fixture.objects.filter(date__range=(gw.start_date, gw.end_date)) \
                                  .select_related('home_team', 'away_team') \
                                  .prefetch_related('prediction_set')
        # Attach fixtures to GW instance temporarily for serializer
        gw.fixtures = fixtures

        serializer = GameweekSerializer(gw)
        return Response(serializer.data)