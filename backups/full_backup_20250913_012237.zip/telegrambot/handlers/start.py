# handlers/start.py
from telegram import Update
from telegram.ext import ContextTypes
from asgiref.sync import sync_to_async
from .utils import get_or_create_telegram_user

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_user = update.effective_user
    
    # ✅ run DB logic safely in a thread
    user = await sync_to_async(get_or_create_telegram_user)(telegram_user)

    await update.message.reply_text(
        f"👋 Welcome {telegram_user.first_name}!\n"
        "Your profile is now linked to our platform."
    )